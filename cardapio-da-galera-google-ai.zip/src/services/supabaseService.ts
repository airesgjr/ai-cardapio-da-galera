import { Usuario, Ingrediente, Prato, Evento, Refeicao } from './interface/types';

// Stub file for future Supabase integration

export const getUsuarios = async (): Promise<Usuario[]> => { throw new Error('Not implemented'); };
export const createUsuario = async (data: Omit<Usuario, 'id'>): Promise<Usuario> => { throw new Error('Not implemented'); };
export const updateUsuario = async (id: string, data: Partial<Usuario>): Promise<Usuario> => { throw new Error('Not implemented'); };
export const deleteUsuario = async (id: string): Promise<void> => { throw new Error('Not implemented'); };

export const getIngredientes = async (): Promise<Ingrediente[]> => { throw new Error('Not implemented'); };
export const createIngrediente = async (data: Omit<Ingrediente, 'id'>): Promise<Ingrediente> => { throw new Error('Not implemented'); };
export const updateIngrediente = async (id: string, data: Partial<Ingrediente>): Promise<Ingrediente> => { throw new Error('Not implemented'); };
export const deleteIngrediente = async (id: string): Promise<void> => { throw new Error('Not implemented'); };

export const getPratos = async (): Promise<Prato[]> => { throw new Error('Not implemented'); };
export const createPrato = async (data: Omit<Prato, 'id'>): Promise<Prato> => { throw new Error('Not implemented'); };
export const updatePrato = async (id: string, data: Partial<Prato>): Promise<Prato> => { throw new Error('Not implemented'); };
export const deletePrato = async (id: string): Promise<void> => { throw new Error('Not implemented'); };

export const getEventos = async (): Promise<Evento[]> => { throw new Error('Not implemented'); };
export const createEvento = async (data: Omit<Evento, 'id'>): Promise<Evento> => { throw new Error('Not implemented'); };
export const updateEvento = async (id: string, data: Partial<Evento>): Promise<Evento> => { throw new Error('Not implemented'); };
export const deleteEvento = async (id: string): Promise<void> => { throw new Error('Not implemented'); };

export const getRefeicoes = async (): Promise<Refeicao[]> => { throw new Error('Not implemented'); };
export const createRefeicao = async (data: Omit<Refeicao, 'id'>): Promise<Refeicao> => { throw new Error('Not implemented'); };
export const updateRefeicao = async (id: string, data: Partial<Refeicao>): Promise<Refeicao> => { throw new Error('Not implemented'); };
export const deleteRefeicao = async (id: string): Promise<void> => { throw new Error('Not implemented'); };

export const getIngredientesEventos = async (eventoId: string) => { throw new Error('Not implemented'); };
