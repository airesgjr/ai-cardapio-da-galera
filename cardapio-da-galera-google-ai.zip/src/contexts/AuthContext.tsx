import React, { createContext, useContext, useState, useEffect } from 'react';
import { Usuario } from '../services/interface/types';
import { getUsuarios } from '../services/mockService';

interface AuthContextType {
  user: Usuario | null;
  login: (email: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<Usuario | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = async (email: string) => {
    const usuarios = await getUsuarios();
    let foundUser = usuarios.find(u => u.email === email);
    
    // Fake login: if user doesn't exist, we just simulate a login with a dummy user if we wanted,
    // but the prompt says "Aceitar qualquer email/senha" so let's just create a dummy session if not found,
    // or better, require them to register first. The prompt says "Sistema deve permitir o cadastro por email".
    // "Tela de login só para simular UX. Aceitar qualquer email/senha".
    if (!foundUser) {
      foundUser = {
        id: 'fake-id',
        nome: 'Usuário Teste',
        email,
        cidade: 'Cidade',
        estado: 'Estado'
      };
    }

    setUser(foundUser);
    localStorage.setItem('currentUser', JSON.stringify(foundUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
